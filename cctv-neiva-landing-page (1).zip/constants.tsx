import React from 'react';
import { PricingPackage, Testimonial, FaqItem } from './types';
import { Shield, Video, Wrench, Building2 } from 'lucide-react';

export const CONTACT_INFO = {
  whatsapp: "17806959756",
  email: "ventas@cctvneiva.com",
  phoneDisplay: "+1 780 695 9756"
};

export const SERVICES = [
  {
    title: "Venta e Instalación de CCTV",
    description: "Suministro de kits de cámaras IP y análogas de alta definición (1080p y 5MP). Instalación técnica certificada con cableado UTP categoría 6 para máxima durabilidad en su hogar o empresa.",
    icon: <Video className="w-8 h-8 text-secondary" />
  },
  {
    title: "Sistemas de Seguridad para Negocios",
    description: "Videovigilancia robusta para locales comerciales en Neiva. Grabación continua 24/7, visión nocturna a color y monitoreo remoto desde celular sin mensualidades.",
    icon: <Wrench className="w-8 h-8 text-secondary" />
  },
  {
    title: "Mantenimiento y Soporte Técnico",
    description: "¿Sus cámaras dejaron de verse? Realizamos diagnóstico, cambio de fuentes, baluns, discos duros y configuración de visualización remota en todo el Huila.",
    icon: <Shield className="w-8 h-8 text-secondary" />
  },
  {
    title: "Proyectos IP y Cableado Estructurado",
    description: "Implementación de NVRs y cámaras IP para conjuntos residenciales y edificios. Soluciones PoE de largo alcance y redes certificadas bajo normativa técnica.",
    icon: <Building2 className="w-8 h-8 text-secondary" />
  }
];

export const PACKAGES: PricingPackage[] = [
  {
    id: 'home',
    title: 'Cámara Inteligente WiFi',
    description: 'Solución práctica y estética. Cámara robótica con seguimiento de movimiento y audio bidireccional. Ideal para interiores, vigilancia de niños o mascotas.',
    priceLabel: 'Venta + Configuración',
    type: 'home',
    image: 'https://m.media-amazon.com/images/I/61c3t9sd5tL.jpg',
    features: [
      { text: 'Cámara WiFi Alta Definición (2MP/4MP)', included: true },
      { text: 'Audio Bidireccional (Habla y Escucha)', included: true },
      { text: 'Visión Nocturna Inteligente', included: true },
      { text: 'Sin cables de video visibles', included: true },
      { text: 'App Celular Gratuita (Sin Mensualidad)', included: true },
      { text: 'Soporte para grabación en MicroSD', included: true },
      { text: 'Instalación y configuración en Neiva', included: true },
    ]
  },
  {
    id: 'business',
    title: 'Kit Profesional CCTV',
    description: 'Sistema cableado de alto rendimiento para grabación continua. Estabilidad total, resistencia a la intemperie (IP67) y gestión centralizada.',
    priceLabel: 'Todo Incluido',
    type: 'business',
    recommended: true,
    image: 'https://m.media-amazon.com/images/I/61lRWGPk3gL.jpg',
    features: [
      { text: '4 Cámaras Turbo HD 1080p (Bala/Domo)', included: true },
      { text: 'DVR 4 Canales con Inteligencia Artificial', included: true },
      { text: 'Disco Duro Especializado para CCTV', included: true },
      { text: 'Cableado UTP 100% Cobre Certificado', included: true },
      { text: 'Fuentes, Video Baluns y Cajas de Paso', included: true },
      { text: 'Visualización Remota Estable 24/7', included: true },
      { text: 'Garantía real y soporte técnico', included: true },
    ]
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "Carlos Rodríguez",
    role: "Comerciante",
    location: "Neiva Centro",
    rating: 5,
    content: "Excelente asesoría. Me instalaron un sistema completo para vigilar la caja y la bodega. La calidad de la imagen es muy nítida y la aplicación funciona perfecto en mi celular."
  },
  {
    id: 2,
    name: "Marta Lucía Gómez",
    role: "Propietaria de Casa",
    location: "Barrio Palermo",
    rating: 5,
    content: "Muy profesionales. Instalaron cámaras en mi casa y fueron muy cuidadosos con la estética del cableado. Me explicaron con paciencia cómo ver las grabaciones."
  },
  {
    id: 3,
    name: "Jorge Martínez",
    role: "Administrador",
    location: "Finca en Rivera",
    rating: 5,
    content: "Contratamos el mantenimiento para el sistema de seguridad perimetral. Recuperaron cámaras que creíamos dañadas y organizaron todo el rack. Servicio técnico de calidad."
  }
];

export const FAQS: FaqItem[] = [
  {
    question: "¿Qué pasa si se va la luz o el internet?",
    answer: "Si se va el internet, el sistema (DVR/NVR) SIGUE GRABANDO localmente en el disco duro, asegurando que no pierda evidencia. Si se va la luz, el sistema se apaga, a menos que instalemos una UPS (batería de respaldo) que mantiene las cámaras encendidas."
  },
  {
    question: "¿Los equipos tienen garantía?",
    answer: "Absolutamente. Solo instalamos equipos nuevos, originales y de importación legal con tecnología de vanguardia. Ofrecemos garantía directa por defectos de fábrica y respaldo sobre la mano de obra de instalación."
  },
  {
    question: "¿Debo pagar alguna mensualidad por ver las cámaras?",
    answer: "No. Nuestros sistemas de circuito cerrado son de pago único. Usted es el dueño absoluto de los equipos. La visualización remota a través de la aplicación móvil es gratuita de por vida."
  },
  {
    question: "¿Cuánto tiempo de grabación almacena el sistema?",
    answer: "Depende de la capacidad del Disco Duro y la cantidad de cámaras. Un kit estándar suele configurarse para almacenar entre 15 y 30 días de grabación continua, sobreescribiendo automáticamente lo más antiguo."
  },
  {
    question: "¿Realizan visitas técnicas de inspección en Neiva?",
    answer: "Sí. Para hogares y pequeños negocios podemos cotizar ágilmente por WhatsApp. Para proyectos más complejos, edificios o fincas, agendamos una visita técnica para evaluar puntos ciegos y cableado."
  },
  {
    question: "¿Cuál es la diferencia entre WiFi y Cableadas?",
    answer: "Las cámaras WiFi son ideales para soluciones sencillas sin cableado visible. Las cámaras cableadas ofrecen mayor estabilidad, seguridad y grabación ininterrumpida, siendo el estándar profesional para negocios."
  }
];

export const COVERAGE_AREAS = [
  "Neiva Centro", "Barrio Altico", "Las Granjas", "Zona Industrial", 
  "Ipanema", "Los Cambulos", "Cándido", "Las Palmas",
  "Rivera", "Palermo", "Campoalegre", "Aipe",
  "El Caguán", "Fortalecillas", "Villa Café", "El Limonar"
];