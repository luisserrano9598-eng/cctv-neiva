import { ReactNode } from 'react';

export interface FeatureItem {
  text: string;
  included: boolean;
}

export interface PricingPackage {
  id: string;
  title: string;
  description: string;
  priceLabel: string;
  features: FeatureItem[];
  recommended?: boolean;
  type: 'home' | 'business';
  image?: string;
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  content: string;
  rating: number;
  location: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface ServiceItem {
  title: string;
  description: string;
  icon: ReactNode;
}