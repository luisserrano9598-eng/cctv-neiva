import React from 'react';
import { CheckCircle, MessageCircle, Phone, Home } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Gracias: React.FC = () => {
  // URL de WhatsApp dinámica usando la constante global
  const whatsappUrl = `https://wa.me/${CONTACT_INFO.whatsapp}?text=Hola,%20acabo%20de%20enviar%20el%20formulario`;

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 font-sans">
      <div className="bg-white w-full max-w-md p-8 md:p-12 rounded-3xl shadow-xl text-center animate-in fade-in zoom-in duration-500">
        
        <div className="flex justify-center mb-8">
          <div className="bg-green-50 p-4 rounded-full">
            <CheckCircle className="w-16 h-16 text-accent" strokeWidth={2.5} />
          </div>
        </div>

        <h1 className="text-3xl font-bold text-primary mb-4">
          ¡Gracias por tu solicitud!
        </h1>
        
        <p className="text-slate-600 mb-10 leading-relaxed">
          Hemos recibido tu información correctamente. Nuestro equipo de expertos te contactará en menos de 24 horas para asesorarte.
        </p>

        <div className="space-y-4">
          <a 
            href={whatsappUrl}
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-3 w-full bg-accent hover:bg-green-600 text-white font-bold py-4 rounded-xl transition-all shadow-lg hover:shadow-green-500/30 transform hover:-translate-y-1"
          >
            <MessageCircle size={20} />
            Escribir por WhatsApp
          </a>

          <a 
            href={`tel:+${CONTACT_INFO.whatsapp}`}
            className="flex items-center justify-center gap-3 w-full bg-secondary hover:bg-sky-600 text-white font-bold py-4 rounded-xl transition-all shadow-lg hover:shadow-sky-500/30 transform hover:-translate-y-1"
          >
            <Phone size={20} />
            Llamar ahora
          </a>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-100">
          <a 
            href="/" 
            className="inline-flex items-center gap-2 text-slate-400 hover:text-primary font-medium transition-colors text-sm"
          >
            <Home size={16} />
            Volver al Inicio
          </a>
        </div>

      </div>
    </div>
  );
};

export default Gracias;