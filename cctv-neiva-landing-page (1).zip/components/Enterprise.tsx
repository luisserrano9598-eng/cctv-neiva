import React from 'react';
import { Building, Warehouse, Users } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Enterprise: React.FC = () => {
  return (
    <section id="proyectos" className="py-20 bg-white overflow-hidden scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          
          <div className="lg:w-1/2 order-2 lg:order-1">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-secondary/10 rounded-full -z-10"></div>
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-accent/10 rounded-full -z-10"></div>
              <img 
                src="https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1200&auto=format&fit=crop" 
                alt="Proyecto de seguridad electrónica empresarial y monitoreo en Neiva" 
                className="rounded-2xl shadow-2xl w-full object-cover h-[400px]"
              />
              <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur p-4 rounded-lg shadow-lg max-w-xs">
                <p className="font-bold text-primary text-sm">Proyectos Certificados</p>
                <p className="text-xs text-slate-600">Cumplimiento de normativa técnica.</p>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 order-1 lg:order-2">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">Videovigilancia Corporativa e Industrial</h2>
            <p className="text-slate-600 text-lg mb-8">
              Expertos en seguridad electrónica a gran escala. Diseñamos e implementamos sistemas robustos con cámaras IP, enlaces inalámbricos y fibra óptica para conjuntos residenciales, fincas y el sector industrial de Neiva y Huila.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <Warehouse className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-800">Seguridad Perimetral e Industrial</h3>
                  <p className="text-sm text-slate-500">Cámaras con inteligencia artificial para detección humana, térmicas y PTZ de largo alcance para grandes superficies.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <Users className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-800">Conjuntos Residenciales</h3>
                  <p className="text-sm text-slate-500">Control de acceso vehicular, reconocimiento de placas (LPR) y monitoreo centralizado de zonas comunes.</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <Building className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-800">Cableado Estructurado</h3>
                  <p className="text-sm text-slate-500">Instalaciones profesionales, certificación de puntos de red, organización de racks y cableado certificado.</p>
                </div>
              </div>
            </div>

            <div className="mt-10">
              <a 
                 href={`https://wa.me/${CONTACT_INFO.whatsapp}?text=Hola,%20necesito%20una%20visita%20técnica%20empresarial.`}
                 target="_blank"
                 rel="noopener noreferrer"
                 className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-secondary bg-blue-50 hover:bg-blue-100 transition-colors"
              >
                Agendar Visita Técnica Empresarial
              </a>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Enterprise;