import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Loader2, Bot } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { SERVICES, PACKAGES, FAQS, COVERAGE_AREAS, CONTACT_INFO } from '../constants';

interface Message {
  role: 'user' | 'model';
  text: string;
}

const ChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: '¡Hola! 👋 Soy el asistente virtual de CCTV Neiva. ¿En qué puedo ayudarte hoy? (Instalación, soporte, zonas de cobertura...)' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  // Construimos el contexto del sistema con la información REAL de la página
  const buildSystemContext = () => {
    const servicesText = SERVICES.map(s => `- ${s.title}: ${s.description}`).join('\n');
    const packagesText = PACKAGES.map(p => `- ${p.title}: ${p.description}. Ideal para: ${p.type}`).join('\n');
    const faqsText = FAQS.map(f => `P: ${f.question} R: ${f.answer}`).join('\n');
    const coverageText = COVERAGE_AREAS.join(', ');
    
    return `
      Eres el asistente virtual inteligente de "CCTV Neiva", una empresa líder en venta e instalación de cámaras de seguridad en Neiva y Huila.
      
      TU CONOCIMIENTO (Contexto del sitio):
      1. SERVICIOS:
      ${servicesText}
      
      2. PAQUETES COMERCIALES:
      ${packagesText}
      
      3. COBERTURA:
      Atendemos en: ${coverageText}. También hacemos envíos a todo el Huila.
      
      4. PREGUNTAS FRECUENTES:
      ${faqsText}
      
      REGLAS ESTRICTAS DE COMPORTAMIENTO:
      1. OBJETIVO: Tu meta principal es resolver dudas operativas (cobertura, características técnicas, horarios) y LLEVAR AL CLIENTE A WHATSAPP para cerrar la venta.
      2. PRECIOS: NO des precios numéricos específicos (aunque los conozcas o intuyas). Los precios cambian.
         - Si el usuario pregunta "¿Cuánto cuesta?" o "Precio", responde: "Los precios varían según el kit y la instalación específica que necesites. Manejamos excelentes ofertas. Por favor contáctanos por WhatsApp para una cotización formal y personalizada." y sugiere el botón de WhatsApp.
      3. TONO: Profesional, amable, conciso y experto en seguridad. Habla en Español de Colombia.
      4. LONGITUD: Mantén tus respuestas cortas (máximo 2-3 párrafos pequeños).
      5. CONTACTO: Si no sabes la respuesta, sugiere contactar al técnico: ${CONTACT_INFO.phoneDisplay}.
    `;
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsTyping(true);

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        console.warn("API Key no encontrada en process.env.API_KEY");
        throw new Error("API Key no configurada");
      }

      const ai = new GoogleGenAI({ apiKey });
      const systemInstructionText = buildSystemContext();
      
      const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          // La librería espera un string directo para systemInstruction
          systemInstruction: systemInstructionText,
          temperature: 0.7,
        }
      });

      // La librería espera un objeto { message: string }
      const result = await chat.sendMessage({ message: userMessage });
      const responseText = result.text;

      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      console.error("Error al conectar con IA:", error);
      // Fallback elegante si no hay API Key o hay error de red
      setTimeout(() => {
        setMessages(prev => [...prev, { 
          role: 'model', 
          text: 'Para brindarte la información más precisa y actualizada sobre precios e instalación, por favor escríbenos directamente a nuestro WhatsApp. Un asesor humano te atenderá de inmediato.' 
        }]);
      }, 500);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end font-sans">
      
      {/* Chat Window */}
      {isOpen && (
        <div className="bg-white rounded-2xl shadow-2xl w-[90vw] md:w-96 mb-4 border border-gray-200 overflow-hidden flex flex-col animate-in slide-in-from-bottom-10 fade-in duration-300 max-h-[500px]">
          
          {/* Header */}
          <div className="bg-primary p-4 flex justify-between items-center shadow-sm shrink-0">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-2 h-2 bg-green-500 rounded-full absolute bottom-0 right-0 border border-primary"></div>
                <div className="bg-white/10 p-1.5 rounded-full">
                  <Bot size={20} className="text-white" />
                </div>
              </div>
              <div>
                <span className="text-white font-bold text-sm block">Soporte CCTV Neiva</span>
                <span className="text-slate-300 text-[10px] block">En línea ahora</span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/80 hover:text-white transition-colors">
              <X size={20} />
            </button>
          </div>
          
          {/* Messages Area */}
          <div className="flex-grow bg-slate-50 p-4 overflow-y-auto space-y-4 min-h-[300px]">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-2xl p-3 text-sm shadow-sm ${
                  msg.role === 'user' 
                    ? 'bg-secondary text-white rounded-tr-none' 
                    : 'bg-white text-slate-700 border border-gray-100 rounded-tl-none'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white border border-gray-100 rounded-2xl rounded-tl-none p-3 shadow-sm flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-secondary" />
                  <span className="text-xs text-slate-400">Escribiendo...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 bg-white border-t border-gray-100 shrink-0">
            <div className="flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2 focus-within:ring-2 focus-within:ring-secondary/20 transition-all">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Escribe tu pregunta aquí..." 
                className="bg-transparent outline-none text-sm text-slate-700 w-full placeholder:text-slate-400"
                autoFocus
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isTyping}
                className={`text-secondary transition-colors ${!input.trim() ? 'opacity-50 cursor-not-allowed' : 'hover:text-sky-700'}`}
              >
                <Send size={18} />
              </button>
            </div>
            <div className="text-center mt-2">
              <a 
                href={`https://wa.me/${CONTACT_INFO.whatsapp}?text=Hola,%20necesito%20asesoría%20personalizada`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] text-slate-500 hover:text-secondary underline decoration-dotted"
              >
                ¿Prefieres hablar por WhatsApp? Clic aquí
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="group bg-secondary hover:bg-sky-600 text-white p-4 rounded-full shadow-lg hover:shadow-sky-500/40 transition-all transform hover:scale-110 relative"
        aria-label="Abrir chat de soporte"
      >
        {!isOpen && (
          <span className="absolute top-0 right-0 -mt-1 -mr-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
          </span>
        )}
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
        
        {/* Tooltip */}
        {!isOpen && (
          <div className="absolute right-full mr-4 top-1/2 -translate-y-1/2 bg-white text-slate-800 px-3 py-1.5 rounded-lg shadow-md text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none hidden md:block">
            ¡Hola! ¿Te ayudo?
          </div>
        )}
      </button>
    </div>
  );
};

export default ChatWidget;