import React from 'react';
import { Check, AlertCircle } from 'lucide-react';
import { PACKAGES, CONTACT_INFO } from '../constants';

const Packages: React.FC = () => {
  return (
    <section id="paquetes" className="py-20 bg-slate-50 scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Kits de Seguridad Todo Incluido</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Paquetes diseñados para ofrecer la mejor relación costo-beneficio. Equipos de última generación con instalación profesional, sin contratos, sin mensualidades y sin pagos ocultos.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {PACKAGES.map((pkg) => {
            const isHome = pkg.type === 'home';
            const themeColor = isHome ? 'border-accent ring-4 ring-accent' : 'border-secondary ring-4 ring-secondary';
            const bgColor = isHome ? 'bg-accent' : 'bg-secondary';
            const hoverBgColor = isHome ? 'hover:bg-green-600' : 'hover:bg-sky-600';
            const shadowColor = isHome ? 'shadow-green-100' : 'shadow-blue-100';
            const textColor = isHome ? 'text-green-700' : 'text-sky-700';
            const bannerText = isHome ? 'IDEAL PARA HOGAR' : 'RECOMENDADO NEGOCIOS';
            const lightBg = isHome ? 'bg-green-50' : 'bg-sky-50';

            return (
              <div 
                key={pkg.id} 
                className={`relative bg-white rounded-2xl overflow-hidden transition-all duration-300 ${themeColor} shadow-2xl ${shadowColor} scale-[1.02]`}
              >
                <div className={`${bgColor} text-white text-center py-3 font-bold text-sm uppercase tracking-wider shadow-sm`}>
                  {bannerText}
                </div>
                
                <div className="p-8">
                  <div className="flex flex-col xl:flex-row gap-6">
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div className="w-full">
                          <h3 className={`text-3xl font-extrabold uppercase tracking-tight mb-2 ${textColor}`}>
                            {pkg.title}
                          </h3>
                          <p className="text-slate-500 text-sm leading-relaxed">{pkg.description}</p>
                        </div>
                      </div>

                      <div className={`my-6 pb-6 border-b border-gray-100 rounded-xl p-4 ${lightBg}`}>
                        <span className="text-3xl font-extrabold text-slate-800">{pkg.priceLabel}</span>
                        <p className="text-xs text-slate-500 mt-1 font-medium">*Equipos Originales + Mano de Obra Calificada</p>
                      </div>

                      <ul className="space-y-4 mb-8">
                        {pkg.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-3 group">
                            {feature.included ? (
                              <div className={`${lightBg} rounded-full p-1 mt-0.5 shrink-0 group-hover:scale-110 transition-transform`}>
                                <Check className={`w-5 h-5 ${isHome ? 'text-green-600' : 'text-sky-600'}`} />
                              </div>
                            ) : (
                              <div className="bg-gray-50 rounded-full p-1 mt-0.5 shrink-0">
                                <AlertCircle className="w-5 h-5 text-gray-400" />
                              </div>
                            )}
                            <span className={`text-sm font-medium ${feature.included ? 'text-slate-700' : 'text-gray-400 line-through'}`}>
                              {feature.text}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {pkg.image && (
                      <div className="w-full xl:w-5/12 flex items-center justify-center xl:justify-end mb-6 xl:mb-0 order-first xl:order-last">
                         <img 
                           src={pkg.image} 
                           alt={isHome ? "Cámara de seguridad WiFi para interiores en Neiva" : "Kit de cámaras de seguridad CCTV profesional para negocio"} 
                           className="w-full max-w-sm rounded-lg shadow-md object-cover" 
                         />
                      </div>
                    )}
                  </div>

                  <a 
                    href={`https://wa.me/${CONTACT_INFO.whatsapp}?text=Hola,%20me%20interesa%20el%20${pkg.title}%20con%20instalación`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`block w-full py-4 text-center rounded-xl font-bold text-white text-lg uppercase tracking-wide shadow-lg transition-all transform hover:-translate-y-1 ${bgColor} ${hoverBgColor}`}
                  >
                    Cotizar Ahora
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-16 overflow-x-auto max-w-4xl mx-auto bg-white rounded-xl shadow-sm border border-gray-200 hidden md:block">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-slate-900 font-semibold uppercase text-xs">
              <tr>
                <th className="px-6 py-4">Comparativa Técnica</th>
                <th className="px-6 py-4 text-center text-green-700 font-bold">Cámara WiFi</th>
                <th className="px-6 py-4 text-center text-sky-700 font-bold">CCTV Profesional</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              <tr>
                <td className="px-6 py-4 font-medium">Equipos Incluidos</td>
                <td className="px-6 py-4 text-center">Cámara IP + Memoria</td>
                <td className="px-6 py-4 text-center font-bold">DVR + Cámaras + Disco Duro</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-medium">Instalación</td>
                <td className="px-6 py-4 text-center">Inalámbrica (Configuración)</td>
                <td className="px-6 py-4 text-center font-bold">Cableada (UTP Certificado)</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-medium">Grabación</td>
                <td className="px-6 py-4 text-center">Por Movimiento (SD)</td>
                <td className="px-6 py-4 text-center font-bold">Continua 24 Horas (HDD)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default Packages;