import React from 'react';
import { Mail, Phone, Send } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <section id="contacto" className="py-20 bg-slate-50 scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden max-w-5xl mx-auto flex flex-col md:flex-row">
          
          {/* Info Side */}
          <div className="bg-primary p-10 md:w-2/5 text-white flex flex-col justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-6">Solicite su Asesoría Gratuita</h2>
              <p className="text-slate-300 mb-8">
                No espere a que ocurra un imprevisto. Déjenos sus datos y obtenga una cotización personalizada con respuesta rápida para asegurar su hogar o negocio hoy mismo.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 p-3 rounded-lg">
                    <Phone className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 uppercase font-bold">Línea de Atención</p>
                    <p className="font-semibold">{CONTACT_INFO.phoneDisplay}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 p-3 rounded-lg">
                    <Mail className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 uppercase font-bold">Correo Electrónico</p>
                    <p className="font-semibold">{CONTACT_INFO.email}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 md:mt-0">
              <div className="bg-white/5 p-6 rounded-xl border border-white/10">
                <p className="text-sm text-slate-300 italic">
                  "Su tranquilidad es nuestra prioridad. Instalaciones garantizadas y soporte inmediato."
                </p>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="p-10 md:w-3/5">
            <form 
              action="https://formsubmit.co/luisco24@yahoo.com" 
              method="POST" 
              className="space-y-6"
            >
              {/* Hidden Inputs for FormSubmit Configuration */}
              <input type="hidden" name="_captcha" value="false" />
              <input type="hidden" name="_template" value="box" />
              <input type="hidden" name="_next" value="https://cctvneiva.com/gracias" />

              <div>
                <label htmlFor="nombre" className="block text-sm font-medium text-slate-700 mb-1">Nombre Completo</label>
                <input 
                  type="text" 
                  name="nombre"
                  required
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all bg-gray-50 focus:bg-white"
                  placeholder="Ej: Juan Pérez"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="telefono" className="block text-sm font-medium text-slate-700 mb-1">Celular / WhatsApp</label>
                  <input 
                    type="tel" 
                    name="telefono"
                    required
                    className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all bg-gray-50 focus:bg-white"
                    placeholder="Ej: 300 123 4567"
                  />
                </div>
                <div>
                  <label htmlFor="servicio" className="block text-sm font-medium text-slate-700 mb-1">Tipo de Servicio</label>
                  <select 
                    name="servicio"
                    className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all bg-gray-50 focus:bg-white"
                  >
                    <option value="Venta Kit Hogar">Cotizar Cámaras Hogar</option>
                    <option value="Venta Kit Negocio">Cotizar Kit Negocio</option>
                    <option value="Instalación Solamente">Solo Instalación</option>
                    <option value="Mantenimiento">Soporte Técnico</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="mensaje" className="block text-sm font-medium text-slate-700 mb-1">Detalles de su solicitud</label>
                <textarea 
                  name="mensaje"
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all bg-gray-50 focus:bg-white resize-none"
                  placeholder="Ej: Necesito instalar 4 cámaras en mi local comercial..."
                ></textarea>
              </div>

              <button 
                type="submit"
                className="w-full bg-secondary hover:bg-sky-600 text-white font-bold py-4 rounded-lg shadow-lg hover:shadow-sky-500/30 transition-all flex items-center justify-center gap-2"
              >
                <Send size={18} />
                Solicitar Cotización Gratis
              </button>
            </form>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;