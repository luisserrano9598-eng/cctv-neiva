import React from 'react';
import { ShieldCheck, Facebook, Instagram, Phone, Mail, MessageCircle } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Footer: React.FC = () => {
  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const whatsappUrl = `https://wa.me/${CONTACT_INFO.whatsapp}?text=Hola,%20quiero%20más%20información%20sobre%20sus%20servicios&utm_source=website&utm_medium=footer&utm_campaign=cctv_neiva`;

  return (
    <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          
          {/* Columna 1: Marca y SEO General */}
          <div className="col-span-1 md:col-span-1">
            <a 
              href="#inicio" 
              onClick={(e) => handleScrollTo(e, '#inicio')}
              className="flex items-center gap-2 mb-4 group"
              title="CCTV Neiva - Seguridad Electrónica"
              aria-label="Ir al inicio"
            >
              <ShieldCheck className="w-8 h-8 text-secondary group-hover:text-white transition-colors" />
              <span className="font-bold text-xl text-white">CCTV NEIVA</span>
            </a>
            <p className="text-sm text-slate-400 leading-relaxed mb-4 text-justify">
              Somos especialistas en <strong>venta, instalación y mantenimiento</strong> de sistemas de videovigilancia en Neiva y Huila. Ofrecemos cámaras IP, DVR/NVR de alta definición, visión nocturna y monitoreo remoto sin mensualidades. Garantía real y soporte técnico certificado.
            </p>
          </div>

          {/* Columna 2: Servicios SEO */}
          <div>
            <h4 className="text-white font-bold mb-4">Servicios</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a 
                  href="#paquetes" 
                  onClick={(e) => handleScrollTo(e, '#paquetes')} 
                  className="hover:text-secondary transition-colors"
                  title="Cámaras WiFi"
                >
                  Cámaras WiFi Inteligentes
                </a>
              </li>
              <li>
                <a 
                  href="#paquetes" 
                  onClick={(e) => handleScrollTo(e, '#paquetes')} 
                  className="hover:text-secondary transition-colors"
                  title="Kits CCTV HD"
                >
                  Kits CCTV Alta Definición
                </a>
              </li>
              <li>
                <a 
                  href="#servicios" 
                  onClick={(e) => handleScrollTo(e, '#servicios')} 
                  className="hover:text-secondary transition-colors"
                  title="Soporte Técnico"
                >
                  Mantenimiento y Reparación
                </a>
              </li>
              <li>
                <a 
                  href="#proyectos" 
                  onClick={(e) => handleScrollTo(e, '#proyectos')} 
                  className="hover:text-secondary transition-colors"
                  title="Proyectos Empresariales"
                >
                  Seguridad Empresarial
                </a>
              </li>
            </ul>
          </div>

          {/* Columna 3: Enlaces Rápidos */}
          <div>
            <h4 className="text-white font-bold mb-4">Empresa</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a 
                  href="#inicio" 
                  onClick={(e) => handleScrollTo(e, '#inicio')} 
                  className="hover:text-secondary transition-colors"
                >
                  Inicio
                </a>
              </li>
              <li>
                <a 
                  href="#servicios" 
                  onClick={(e) => handleScrollTo(e, '#servicios')} 
                  className="hover:text-secondary transition-colors"
                >
                  Nuestros Servicios
                </a>
              </li>
              <li>
                <a 
                  href="#contacto" 
                  onClick={(e) => handleScrollTo(e, '#contacto')} 
                  className="hover:text-secondary transition-colors"
                >
                  Solicitar Visita
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  className="hover:text-secondary transition-colors"
                >
                  Política de Privacidad
                </a>
              </li>
            </ul>
          </div>

          {/* Columna 4: Contacto */}
          <div>
            <h4 className="text-white font-bold mb-4">Contacto</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-secondary shrink-0" />
                <a 
                  href={`tel:+${CONTACT_INFO.whatsapp}`} 
                  className="hover:text-white transition-colors"
                >
                  {CONTACT_INFO.phoneDisplay}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-secondary shrink-0" />
                <a 
                  href={`mailto:${CONTACT_INFO.email}`} 
                  className="hover:text-white transition-colors"
                >
                  {CONTACT_INFO.email}
                </a>
              </li>
              
              <li className="text-xs text-slate-400 mt-2 italic">
                Servicio disponible en zona urbana y rural.
              </li>

              <li className="mt-4">
                <a 
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-secondary/10 hover:bg-secondary text-secondary hover:text-white border border-secondary px-4 py-2 rounded-full transition-all duration-300 text-xs font-bold uppercase tracking-wide"
                >
                  <MessageCircle className="w-4 h-4" />
                  Chat Asesor
                </a>
              </li>

              <li className="flex gap-4 mt-4">
                <a href="#" className="bg-slate-800 p-2 rounded-full hover:bg-secondary hover:text-white transition-all">
                  <Facebook size={18} />
                </a>
                <a href="#" className="bg-slate-800 p-2 rounded-full hover:bg-secondary hover:text-white transition-all">
                  <Instagram size={18} />
                </a>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500 gap-4">
          <p>&copy; {new Date().getFullYear()} CCTV Neiva. Todos los derechos reservados.</p>
          <p className="text-slate-400 font-medium">Instaladores Profesionales Certificados.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;