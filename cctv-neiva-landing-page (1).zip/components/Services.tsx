import React from 'react';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <section id="servicios" className="py-20 bg-white scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Soluciones Tecnológicas en Cámaras de Seguridad</h2>
          <p className="text-slate-600 text-lg">
            Ofrecemos mucho más que una instalación básica. Brindamos asesoría experta, configuración de equipos de alta gama y soporte garantizado para hogares, fincas y negocios en todo el Huila.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.map((service, index) => (
            <div 
              key={index} 
              className="group bg-slate-50 p-8 rounded-2xl border border-slate-100 hover:border-secondary/30 hover:shadow-xl hover:shadow-blue-100/50 transition-all duration-300"
            >
              <div className="mb-6 bg-white w-16 h-16 rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">{service.title}</h3>
              <p className="text-slate-600 leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;