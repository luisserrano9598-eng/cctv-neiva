import React, { useState, useEffect } from 'react';
import { Menu, X, ShieldCheck, Phone } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Enlaces de navegación optimizados para SEO Local y Accesibilidad
  const navLinks = [
    { 
      name: 'Inicio', 
      href: '#inicio',
      title: 'CCTV Neiva - Expertos en Seguridad Electrónica',
      ariaLabel: 'Volver a la pantalla de inicio'
    },
    { 
      name: 'Servicios CCTV', 
      href: '#servicios',
      title: 'Instalación, mantenimiento y configuración de cámaras',
      ariaLabel: 'Consultar nuestros servicios de seguridad'
    },
    { 
      name: 'Paquetes y Precios', 
      href: '#paquetes',
      title: 'Kits de cámaras para hogar y negocio',
      ariaLabel: 'Ver ofertas y combos de cámaras de seguridad'
    },
    { 
      name: 'Soluciones Empresariales', 
      href: '#proyectos',
      title: 'Proyectos de videovigilancia corporativa en el Huila',
      ariaLabel: 'Ver soluciones para grandes empresas'
    },
    { 
      name: 'Contacto', 
      href: '#contacto',
      title: 'Solicitar asesoría o cotización en Neiva',
      ariaLabel: 'Ir al formulario de contacto'
    },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const element = document.querySelector(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  // URL de WhatsApp con UTM parameters para seguimiento de conversiones
  const whatsappUrl = `https://wa.me/${CONTACT_INFO.whatsapp}?text=Hola,%20quisiera%20cotizar%20cámaras%20de%20seguridad&utm_source=website&utm_medium=header&utm_campaign=cctv_neiva`;

  return (
    <header className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          {/* Logo Optimizado para Autoridad de Marca */}
          <a 
            href="#inicio" 
            onClick={(e) => handleNavClick(e, '#inicio')}
            className="flex items-center gap-2 group"
            title="CCTV Neiva - Especialistas en Cámaras de Seguridad"
            aria-label="CCTV Neiva - Ir al inicio"
          >
            <ShieldCheck className={`w-8 h-8 ${isScrolled ? 'text-secondary' : 'text-white'} transition-colors`} />
            <div className="flex flex-col">
              <span className={`font-bold text-xl leading-none ${isScrolled ? 'text-primary' : 'text-white'}`}>CCTV NEIVA</span>
              <span className={`text-xs font-medium ${isScrolled ? 'text-slate-500' : 'text-slate-200'}`}>Seguridad Inteligente</span>
            </div>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8" role="navigation" aria-label="Menú principal">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className={`text-sm font-medium hover:text-secondary transition-colors ${isScrolled ? 'text-slate-700' : 'text-white'}`}
                title={link.title}
                aria-label={link.ariaLabel}
              >
                {link.name}
              </a>
            ))}
            {/* Botón WhatsApp con UTMs */}
            <a 
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent hover:bg-green-600 text-white px-5 py-2 rounded-full font-bold text-sm flex items-center gap-2 transition-transform hover:scale-105 shadow-lg"
              title="Hablar con un asesor experto en Neiva"
              aria-label="Contactar por WhatsApp ahora"
            >
              <Phone size={16} aria-hidden="true" />
              WhatsApp
            </a>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-slate-700 focus:outline-none"
            onClick={() => setIsOpen(!isOpen)}
            aria-label={isOpen ? "Cerrar menú" : "Abrir menú"}
            aria-expanded={isOpen}
          >
            {isOpen ? (
              <X className={`w-8 h-8 ${isScrolled ? 'text-slate-800' : 'text-white'}`} />
            ) : (
              <Menu className={`w-8 h-8 ${isScrolled ? 'text-slate-800' : 'text-white'}`} />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-xl border-t border-gray-100 py-4 px-4 flex flex-col gap-4 animate-in slide-in-from-top-5">
          {navLinks.map((link) => (
            <a 
              key={link.name}
              href={link.href}
              className="text-slate-700 font-medium py-2 border-b border-gray-100 hover:text-secondary"
              onClick={(e) => handleNavClick(e, link.href)}
              title={link.title}
            >
              {link.name}
            </a>
          ))}
          <a 
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-accent text-white text-center py-3 rounded-lg font-bold mt-2"
            onClick={() => setIsOpen(false)}
            title="Iniciar chat de cotización"
          >
            Cotizar por WhatsApp
          </a>
        </div>
      )}
    </header>
  );
};

export default Header;