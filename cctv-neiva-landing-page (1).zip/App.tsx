import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Packages from './components/Packages';
import Enterprise from './components/Enterprise';
import Coverage from './components/Coverage';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ChatWidget from './components/ChatWidget';
import FloatingWhatsApp from './components/FloatingWhatsApp';

function App() {
  return (
    // Contenedor global de la aplicación
    <div className="min-h-screen flex flex-col w-full overflow-x-hidden">
      
      {/* Landmark: Navegación y Encabezado */}
      <Header />
      
      {/* Landmark: Contenido Principal */}
      {/* role="main" ayuda a la accesibilidad en navegadores antiguos y SEO semántico */}
      <main 
        className="flex-grow" 
        role="main" 
        aria-label="Venta e instalación de cámaras de seguridad y sistemas CCTV en Neiva, Huila"
      >
        {/* Sección Hero: Propuesta de valor principal */}
        <Hero />
        
        {/* Secciones Comerciales: Oferta de valor */}
        <Services />
        <Packages />
        <Enterprise />
        
        {/* Sección Geográfica: SEO Local */}
        <Coverage />
        
        {/* Secciones de Confianza: Prueba social y resolución de dudas */}
        <Testimonials />
        <FAQ />
        
        {/* Sección de Conversión: Contacto final */}
        <Contact />
      </main>
      
      {/* Landmark: Información Corporativa y Enlaces */}
      <Footer />
      
      {/* Elementos Flotantes / Asistencia */}
      {/* Chat a la derecha, WhatsApp a la izquierda para mejor UX móvil */}
      <ChatWidget />
      <FloatingWhatsApp />
    </div>
  );
}

export default App;