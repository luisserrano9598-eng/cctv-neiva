import React from 'react';
import { PricingPackage, Testimonial, FaqItem } from './types';
import { Shield, Video, Wrench, Building2 } from 'lucide-react';

export const CONTACT_INFO = {
  whatsapp: "3000000000", // Placeholder
  email: "ventas@cctvneiva.com",
  phoneDisplay: "300 000 0000"
};

export const SERVICES = [
  {
    title: "Venta de Equipos",
    description: "Distribuimos las mejores marcas del mercado (Hikvision, Dahua, Ezviz). Cámaras bala, domo, PTZ y ocultas con garantía real en Neiva.",
    icon: <Video className="w-8 h-8 text-secondary" />
  },
  {
    title: "Instalación Profesional",
    description: "Técnicos certificados expertos en cableado estructurado y configuración estética. Cero cables sueltos, máxima durabilidad.",
    icon: <Wrench className="w-8 h-8 text-secondary" />
  },
  {
    title: "Servicio Técnico",
    description: "Mantenimiento preventivo y correctivo. ¿Tus cámaras no se ven en el celular? ¿El DVR pita? Nosotros lo solucionamos.",
    icon: <Shield className="w-8 h-8 text-secondary" />
  },
  {
    title: "Proyectos Empresariales",
    description: "Diseño de sistemas de videovigilancia para conjuntos residenciales, edificios, bodegas y parqueaderos con monitoreo centralizado.",
    icon: <Building2 className="w-8 h-8 text-secondary" />
  }
];

export const PACKAGES: PricingPackage[] = [
  {
    id: 'home',
    title: 'Combo Hogar Seguro',
    description: 'Ideal para vigilar la entrada, la sala o el garaje. Simple y efectivo.',
    priceLabel: 'Desde $ Consultar',
    type: 'home',
    features: [
      { text: '1 Cámara WiFi Alta Definición (1080p/4MP)', included: true },
      { text: 'Visión Nocturna Inteligente', included: true },
      { text: 'Audio Bidireccional (Escucha y Habla)', included: true },
      { text: 'App para celular (Android / iPhone)', included: true },
      { text: 'Instalación y configuración básica', included: true },
      { text: 'Soporte técnico post-venta', included: true },
      { text: 'DVR / Grabador físico', included: false },
    ]
  },
  {
    id: 'business',
    title: 'Kit Negocio Protegido',
    description: 'Sistema robusto CCTV para tiendas, oficinas y locales comerciales.',
    priceLabel: 'Mejor Precio Garantizado',
    type: 'business',
    recommended: true,
    features: [
      { text: '4 Cámaras Full HD (Bala o Domo)', included: true },
      { text: 'DVR 4 Canales con Disco Duro', included: true },
      { text: 'Cableado profesional certificado', included: true },
      { text: 'Fuentes de poder y video baluns', included: true },
      { text: 'Configuración para ver en celular', included: true },
      { text: 'Garantía de 1 año en equipos', included: true },
      { text: 'Capacitación de uso', included: true },
    ]
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "Carlos Rodríguez",
    role: "Propietario de Restaurante",
    location: "Barrio Altico",
    rating: 5,
    content: "Excelente servicio. Instalaron 8 cámaras en mi restaurante y todo quedó muy ordenado. La atención post-venta ha sido muy buena."
  },
  {
    id: 2,
    name: "María Fernanda Tovar",
    role: "Ama de Casa",
    location: "Condominio en Palermo",
    rating: 5,
    content: "Quería vigilar mi casa cuando viajo. Me explicaron todo con paciencia y ahora puedo ver todo desde mi iPhone. Muy recomendados."
  },
  {
    id: 3,
    name: "Jorge Perdomo",
    role: "Administrador Edificio",
    location: "Centro de Neiva",
    rating: 5,
    content: "Contratamos el mantenimiento para las cámaras del edificio y recuperaron 3 cámaras que creíamos dañadas. Técnicos muy honestos."
  }
];

export const FAQS: FaqItem[] = [
  {
    question: "¿Cuánto cuesta instalar cámaras en Neiva?",
    answer: "El precio depende de la cantidad de cámaras y la dificultad de la instalación (altura, metros de cable). Sin embargo, manejamos combos con instalación incluida muy económicos. ¡Escríbenos al WhatsApp para una cotización rápida!"
  },
  {
    question: "¿Qué incluye el combo para hogar?",
    answer: "El combo hogar generalmente incluye una cámara IP WiFi de fácil instalación, configuración en su celular, memoria para grabación (opcional) y nuestra garantía de funcionamiento."
  },
  {
    question: "¿Qué garantía ofrecen?",
    answer: "Ofrecemos 1 año de garantía por defectos de fábrica en los equipos (Cámaras y DVR) y 6 meses de garantía sobre la mano de obra de la instalación."
  },
  {
    question: "¿Puedo ver las cámaras desde el celular?",
    answer: "¡Sí! Todos nuestros sistemas, tanto para hogar como empresariales, quedan configurados para que puedas monitorear en tiempo real desde cualquier lugar con tu Smartphone."
  },
  {
    question: "¿Atienden barrios específicos de Neiva?",
    answer: "Cubrimos toda la ciudad de Neiva, incluyendo Las Granjas, Cándido, Palermo, Ipanema, El Tizón, Zona Industrial y municipios aledaños como Rivera o Aipe (con recargo de transporte)."
  }
];

export const COVERAGE_AREAS = [
  "Palermo", "Las Granjas", "Altico", "Cándido Leguízamo", 
  "San Pedro", "Ipanema", "Zona Industrial", "Centro",
  "Las Palmas", "Santa Inés", "Campo Núñez", "El Vergel"
];