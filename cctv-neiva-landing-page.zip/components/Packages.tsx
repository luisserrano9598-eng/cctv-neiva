import React from 'react';
import { Check, AlertCircle } from 'lucide-react';
import { PACKAGES, CONTACT_INFO } from '../constants';

const Packages: React.FC = () => {
  return (
    <section id="paquetes" className="py-20 bg-slate-50 scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Combos y Paquetes</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Selecciona la opción que mejor se adapte a tus necesidades. Instalación llave en mano, sin costos ocultos.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {PACKAGES.map((pkg) => {
            const isHome = pkg.type === 'home';
            // Define colors based on type
            const themeColor = isHome ? 'border-accent ring-accent' : 'border-secondary ring-secondary';
            const bgColor = isHome ? 'bg-accent' : 'bg-secondary';
            const hoverBgColor = isHome ? 'hover:bg-green-600' : 'hover:bg-sky-600';
            const shadowColor = isHome ? 'shadow-green-100' : 'shadow-blue-100';
            const textColor = isHome ? 'text-green-700' : 'text-sky-700';
            const bannerText = isHome ? 'IDEAL PARA HOGAR' : 'MÁS VENDIDO PARA NEGOCIOS';
            const lightBg = isHome ? 'bg-green-50' : 'bg-sky-50';

            return (
              <div 
                key={pkg.id} 
                className={`relative bg-white rounded-2xl overflow-hidden transition-all duration-300 ring-4 ${themeColor} shadow-2xl ${shadowColor} scale-[1.02]`}
              >
                {/* Banner Superior */}
                <div className={`${bgColor} text-white text-center py-3 font-bold text-sm uppercase tracking-wider shadow-sm`}>
                  {bannerText}
                </div>
                
                <div className="p-8">
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-full">
                      <h3 className={`text-3xl font-extrabold uppercase tracking-tight mb-2 ${textColor}`}>
                        {pkg.title}
                      </h3>
                      <p className="text-slate-500 text-sm leading-relaxed">{pkg.description}</p>
                    </div>
                  </div>

                  <div className={`my-6 pb-6 border-b border-gray-100 rounded-xl p-4 ${lightBg}`}>
                    <span className="text-3xl font-extrabold text-slate-800">{pkg.priceLabel}</span>
                    <p className="text-xs text-slate-500 mt-1 font-medium">*Precio sujeto a inspección técnica</p>
                  </div>

                  <ul className="space-y-4 mb-8">
                    {pkg.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-3 group">
                        {feature.included ? (
                          <div className={`${lightBg} rounded-full p-1 mt-0.5 shrink-0 group-hover:scale-110 transition-transform`}>
                            <Check className={`w-5 h-5 ${isHome ? 'text-green-600' : 'text-sky-600'}`} />
                          </div>
                        ) : (
                          <div className="bg-gray-50 rounded-full p-1 mt-0.5 shrink-0">
                            <AlertCircle className="w-5 h-5 text-gray-400" />
                          </div>
                        )}
                        <span className={`text-sm font-medium ${feature.included ? 'text-slate-700' : 'text-gray-400 line-through'}`}>
                          {feature.text}
                        </span>
                      </li>
                    ))}
                  </ul>

                  <a 
                    href={`https://wa.me/57${CONTACT_INFO.whatsapp}?text=Hola,%20estoy%20interesado%20en%20el%20${pkg.title}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`block w-full py-4 text-center rounded-xl font-bold text-white text-lg uppercase tracking-wide shadow-lg transition-all transform hover:-translate-y-1 ${bgColor} ${hoverBgColor}`}
                  >
                    Solicitar este Paquete
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Comparison Table for Desktop */}
        <div className="mt-16 overflow-x-auto max-w-4xl mx-auto bg-white rounded-xl shadow-sm border border-gray-200 hidden md:block">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-slate-900 font-semibold uppercase text-xs">
              <tr>
                <th className="px-6 py-4">Característica</th>
                <th className="px-6 py-4 text-center text-green-700 font-bold">Combo Hogar</th>
                <th className="px-6 py-4 text-center text-sky-700 font-bold">Kit Negocio</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              <tr>
                <td className="px-6 py-4 font-medium">Cantidad de Cámaras</td>
                <td className="px-6 py-4 text-center">1 (Expandible WiFi)</td>
                <td className="px-6 py-4 text-center font-bold">4 (Expandible a 8/16)</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-medium">Grabación</td>
                <td className="px-6 py-4 text-center">MicroSD (Limitada)</td>
                <td className="px-6 py-4 text-center font-bold">Disco Duro (Semanas)</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-medium">Estabilidad</td>
                <td className="px-6 py-4 text-center">Depende del WiFi</td>
                <td className="px-6 py-4 text-center font-bold">Cableada (100% Estable)</td>
              </tr>
              <tr>
                <td className="px-6 py-4 font-medium">Monitoreo Remoto</td>
                <td className="px-6 py-4 text-center text-green-600 font-bold">Sí (App Celular)</td>
                <td className="px-6 py-4 text-center text-sky-600 font-bold">Sí (App Celular)</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};

export default Packages;