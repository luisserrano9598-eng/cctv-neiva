import React, { useState } from 'react';
import { Mail, Phone, Send } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    service: 'Instalación Hogar',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Format message for WhatsApp
    const text = `Hola, mi nombre es *${formData.name}*. Estoy interesado en *${formData.service}*. Teléfono: ${formData.phone}. Mensaje: ${formData.message}`;
    const url = `https://wa.me/57${CONTACT_INFO.whatsapp}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contacto" className="py-20 bg-slate-50 scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden max-w-5xl mx-auto flex flex-col md:flex-row">
          
          {/* Info Side */}
          <div className="bg-primary p-10 md:w-2/5 text-white flex flex-col justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-6">Hablemos de Seguridad</h3>
              <p className="text-slate-300 mb-8">
                Déjanos tus datos y un asesor experto te contactará en menos de 24 horas para darte la mejor solución.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 p-3 rounded-lg">
                    <Phone className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 uppercase font-bold">Llámanos</p>
                    <p className="font-semibold">{CONTACT_INFO.phoneDisplay}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 p-3 rounded-lg">
                    <Mail className="w-6 h-6 text-secondary" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-400 uppercase font-bold">Escríbenos</p>
                    <p className="font-semibold">{CONTACT_INFO.email}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 md:mt-0">
              <div className="bg-white/5 p-6 rounded-xl border border-white/10">
                <p className="text-sm text-slate-300 italic">
                  "La seguridad no es un gasto, es una inversión en tranquilidad."
                </p>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="p-10 md:w-3/5">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1">Nombre Completo</label>
                <input 
                  type="text" 
                  name="name"
                  required
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all bg-gray-50 focus:bg-white"
                  placeholder="Ej: Juan Pérez"
                  onChange={handleChange}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-slate-700 mb-1">Teléfono / Celular</label>
                  <input 
                    type="tel" 
                    name="phone"
                    required
                    className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all bg-gray-50 focus:bg-white"
                    placeholder="Ej: 310 123 4567"
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <label htmlFor="service" className="block text-sm font-medium text-slate-700 mb-1">Servicio de Interés</label>
                  <select 
                    name="service"
                    className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all bg-gray-50 focus:bg-white"
                    onChange={handleChange}
                  >
                    <option value="Instalación Hogar">Combo Hogar</option>
                    <option value="Kit Negocio">Kit Negocio</option>
                    <option value="Mantenimiento">Mantenimiento</option>
                    <option value="Proyecto Empresarial">Proyecto Empresarial</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-slate-700 mb-1">Mensaje (Opcional)</label>
                <textarea 
                  name="message"
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-secondary focus:ring-2 focus:ring-secondary/20 outline-none transition-all bg-gray-50 focus:bg-white resize-none"
                  placeholder="Cuéntanos más detalles de lo que necesitas..."
                  onChange={handleChange}
                ></textarea>
              </div>

              <button 
                type="submit"
                className="w-full bg-secondary hover:bg-sky-600 text-white font-bold py-4 rounded-lg shadow-lg hover:shadow-sky-500/30 transition-all flex items-center justify-center gap-2"
              >
                <Send size={18} />
                Enviar Solicitud
              </button>
            </form>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;