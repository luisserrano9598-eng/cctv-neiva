import React from 'react';
import { ShieldCheck, Facebook, Instagram, Phone } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Footer: React.FC = () => {
  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-slate-900 text-slate-300 py-12 border-t border-slate-800">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          
          <div className="col-span-1 md:col-span-1">
            <a 
              href="#inicio" 
              onClick={(e) => handleScrollTo(e, '#inicio')}
              className="flex items-center gap-2 mb-4"
            >
              <ShieldCheck className="w-8 h-8 text-secondary" />
              <span className="font-bold text-xl text-white">CCTV NEIVA</span>
            </a>
            <p className="text-sm text-slate-400 leading-relaxed">
              Líderes en venta, instalación y mantenimiento de sistemas de seguridad electrónica en Neiva y el departamento del Huila.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Servicios</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#paquetes" onClick={(e) => handleScrollTo(e, '#paquetes')} className="hover:text-secondary transition-colors">Cámaras para Hogar</a></li>
              <li><a href="#paquetes" onClick={(e) => handleScrollTo(e, '#paquetes')} className="hover:text-secondary transition-colors">Cámaras para Negocio</a></li>
              <li><a href="#servicios" onClick={(e) => handleScrollTo(e, '#servicios')} className="hover:text-secondary transition-colors">Mantenimiento CCTV</a></li>
              <li><a href="#proyectos" onClick={(e) => handleScrollTo(e, '#proyectos')} className="hover:text-secondary transition-colors">Proyectos IP</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#inicio" onClick={(e) => handleScrollTo(e, '#inicio')} className="hover:text-secondary transition-colors">Inicio</a></li>
              <li><a href="#servicios" onClick={(e) => handleScrollTo(e, '#servicios')} className="hover:text-secondary transition-colors">Nosotros</a></li>
              <li><a href="#contacto" onClick={(e) => handleScrollTo(e, '#contacto')} className="hover:text-secondary transition-colors">Solicitar Cotización</a></li>
              <li><a href="#" className="hover:text-secondary transition-colors">Política de Privacidad</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4">Contacto</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-secondary" />
                {CONTACT_INFO.phoneDisplay}
              </li>
              <li className="flex gap-4 mt-4">
                <a href="#" className="bg-slate-800 p-2 rounded-full hover:bg-secondary hover:text-white transition-all">
                  <Facebook size={20} />
                </a>
                <a href="#" className="bg-slate-800 p-2 rounded-full hover:bg-secondary hover:text-white transition-all">
                  <Instagram size={20} />
                </a>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500">
          <p>&copy; {new Date().getFullYear()} CCTV Neiva. Todos los derechos reservados.</p>
          <p className="mt-2 md:mt-0">Diseñado para proteger lo que más importa.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;