import React, { useState } from 'react';
import { MessageSquare, X, Send } from 'lucide-react';

const ChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      
      {/* Chat Window */}
      {isOpen && (
        <div className="bg-white rounded-2xl shadow-2xl w-80 mb-4 border border-gray-200 overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-300">
          <div className="bg-primary p-4 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-white font-bold text-sm">Asesor Virtual</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/80 hover:text-white">
              <X size={18} />
            </button>
          </div>
          
          <div className="h-64 bg-gray-50 p-4 overflow-y-auto">
            <div className="flex flex-col gap-3">
              <div className="self-start bg-white p-3 rounded-2xl rounded-tl-none shadow-sm text-sm text-slate-700 border border-gray-100">
                ¡Hola! 👋 Bienvenido a CCTV Neiva. ¿En qué te puedo ayudar hoy?
              </div>
              <div className="self-start bg-white p-3 rounded-2xl rounded-tl-none shadow-sm text-sm text-slate-700 border border-gray-100">
                Puedes preguntarme por precios, instalaciones o soporte técnico.
              </div>
            </div>
          </div>

          <div className="p-3 bg-white border-t border-gray-100">
            <div className="flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2">
              <input 
                type="text" 
                placeholder="Escribe tu mensaje..." 
                className="bg-transparent outline-none text-sm text-slate-700 w-full"
                disabled
              />
              <button className="text-secondary opacity-50 cursor-not-allowed">
                <Send size={16} />
              </button>
            </div>
            <div className="text-center mt-2">
              <p className="text-[10px] text-slate-400">Chat IA Próximamente</p>
            </div>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="bg-secondary hover:bg-sky-600 text-white p-4 rounded-full shadow-lg hover:shadow-sky-500/40 transition-all transform hover:scale-110"
      >
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
      </button>
    </div>
  );
};

export default ChatWidget;