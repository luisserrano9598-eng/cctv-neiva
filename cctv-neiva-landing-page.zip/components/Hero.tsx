import React from 'react';
import { ChevronRight, PhoneCall } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Hero: React.FC = () => {
  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="inicio" className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1557597774-9d273605dfa9?q=80&w=2070&auto=format&fit=crop" 
          alt="Instalación de cámaras de seguridad profesional" 
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/95 to-primary/70 mix-blend-multiply"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10 text-center md:text-left">
        <div className="max-w-3xl">
          <div className="inline-block bg-secondary/20 border border-secondary/40 rounded-full px-4 py-1 mb-6 backdrop-blur-sm">
            <span className="text-secondary font-semibold text-sm tracking-wide uppercase">Servicio en todo Neiva y Huila</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-6">
            Venta e instalación de <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-teal-400">cámaras de seguridad</span> en Neiva
          </h1>
          
          <p className="text-lg md:text-xl text-slate-200 mb-8 leading-relaxed max-w-2xl">
            Protege lo que más quieres con tecnología de punta. Especialistas en circuitos cerrados de televisión (CCTV), mantenimiento y configuración para hogares y empresas.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
            <a 
              href={`https://wa.me/57${CONTACT_INFO.whatsapp}?text=Hola,%20me%20interesa%20cotizar%20cámaras%20de%20seguridad`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent hover:bg-green-600 text-white px-8 py-4 rounded-lg font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-lg hover:shadow-green-500/30"
            >
              <PhoneCall size={20} />
              Cotizar Ahora
            </a>
            <a 
              href="#paquetes"
              onClick={(e) => handleScrollTo(e, '#paquetes')}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/30 text-white px-8 py-4 rounded-lg font-semibold text-lg flex items-center justify-center gap-2 transition-all"
            >
              Ver Paquetes
              <ChevronRight size={20} />
            </a>
          </div>

          <div className="mt-12 flex items-center gap-6 justify-center md:justify-start text-slate-300 text-sm font-medium">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              Disponibilidad Inmediata
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              Garantía Certificada
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;