import React from 'react';
import { Building, Warehouse, Users } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Enterprise: React.FC = () => {
  return (
    <section id="proyectos" className="py-20 bg-white overflow-hidden scroll-mt-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          
          <div className="lg:w-1/2 order-2 lg:order-1">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-secondary/10 rounded-full -z-10"></div>
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-accent/10 rounded-full -z-10"></div>
              <img 
                src="https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1200&auto=format&fit=crop" 
                alt="Sistema de seguridad empresarial en Neiva" 
                className="rounded-2xl shadow-2xl w-full object-cover h-[400px]"
              />
              <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur p-4 rounded-lg shadow-lg max-w-xs">
                <p className="font-bold text-primary text-sm">Tecnología IP & HD</p>
                <p className="text-xs text-slate-600">Implementamos salas de monitoreo y video wall.</p>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 order-1 lg:order-2">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">Proyectos Empresariales de Alto Nivel</h2>
            <p className="text-slate-600 text-lg mb-8">
              Desarrollamos infraestructura de seguridad para grandes superficies. Si su empresa, conjunto residencial o bodega requiere un sistema robusto, somos su aliado estratégico en el Huila.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <Warehouse className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-800">Bodegas e Industrias</h4>
                  <p className="text-sm text-slate-500">Cámaras de largo alcance y protección perimetral.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <Users className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-800">Conjuntos Residenciales</h4>
                  <p className="text-sm text-slate-500">Control de acceso vehicular y peatonal con reconocimiento de placas.</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <Building className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-800">Edificios y Oficinas</h4>
                  <p className="text-sm text-slate-500">Estética impecable y monitoreo centralizado.</p>
                </div>
              </div>
            </div>

            <div className="mt-10">
              <a 
                 href={`https://wa.me/57${CONTACT_INFO.whatsapp}?text=Hola,%20requiero%20una%20visita%20técnica%20empresarial`}
                 className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-secondary bg-blue-50 hover:bg-blue-100 transition-colors"
              >
                Agendar Visita Técnica
              </a>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Enterprise;