import React from 'react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../constants';

const Testimonials: React.FC = () => {
  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-primary mb-12">Lo que dicen nuestros clientes</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((testimonial) => (
            <div key={testimonial.id} className="bg-white p-8 rounded-2xl shadow-md hover:shadow-lg transition-shadow border border-gray-100 flex flex-col">
              <div className="mb-4 text-secondary">
                <Quote className="w-8 h-8 opacity-50" />
              </div>
              <p className="text-slate-600 mb-6 flex-grow italic">"{testimonial.content}"</p>
              
              <div className="mt-auto border-t border-gray-100 pt-4">
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <h4 className="font-bold text-slate-800">{testimonial.name}</h4>
                <div className="flex justify-between items-center text-xs text-slate-500 mt-1">
                  <span>{testimonial.role}</span>
                  <span className="bg-gray-100 px-2 py-1 rounded text-gray-600">{testimonial.location}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;